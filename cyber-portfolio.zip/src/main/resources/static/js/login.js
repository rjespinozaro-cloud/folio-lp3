/* ============================================================
   CYBERFOLIO — login.js
   Lógica de autenticación: login y registro
   Base URL configurada para Spring Boot en /api/v1
   ============================================================ */

const API = 'http://localhost:8080/api/v1';

/* ============================================================
   UTILIDADES DOM
   ============================================================ */
const $ = id => document.getElementById(id);
const show = el => el.classList.remove('hidden');
const hide = el => el.classList.add('hidden');

/* ============================================================
   TOAST
   ============================================================ */
function toast(msg, type = 'info') {
  const container = $('toast-container');
  const t = document.createElement('div');
  t.className = `toast ${type}`;

  const icons = { success: 'ti-check', error: 'ti-alert-triangle', info: 'ti-info-circle' };
  t.innerHTML = `<i class="ti ${icons[type] || 'ti-info-circle'}"></i><span>${msg}</span>`;

  container.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

/* ============================================================
   LOADER
   ============================================================ */
function setLoading(btn, loading) {
  if (loading) {
    btn.disabled = true;
    btn.dataset.original = btn.innerHTML;
    btn.innerHTML = `<span class="spinner"></span> PROCESANDO...`;
  } else {
    btn.disabled = false;
    btn.innerHTML = btn.dataset.original;
  }
}

/* ============================================================
   TABS — Login / Registrar
   ============================================================ */
function initTabs() {
  document.querySelectorAll('.login-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.login-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.form-section').forEach(s => s.classList.remove('active'));
      tab.classList.add('active');
      const target = tab.dataset.tab;
      document.getElementById(target).classList.add('active');
      $('form-error').classList.remove('show');
    });
  });
}

/* ============================================================
   MOSTRAR ERROR EN FORMULARIO
   ============================================================ */
function showError(msg) {
  const el = $('form-error');
  el.textContent = `> ERROR: ${msg}`;
  el.classList.add('show');
}

function clearError() {
  $('form-error').classList.remove('show');
}

/* ============================================================
   REDIRIGIR SEGÚN ROL
   ============================================================ */
function redirigirPorRol(rol) {
  const rutas = {
    'ADMINISTRADOR': 'dashboard-admin.html',
    'INSTRUCTOR':    'dashboard-instructor.html',
    'ESTUDIANTE':    'dashboard-estudiante.html',
  };
  const destino = rutas[rol];
  if (destino) {
    window.location.href = destino;
  } else {
    showError('Rol no reconocido: ' + rol);
  }
}

/* ============================================================
   GUARDAR SESIÓN EN LOCALSTORAGE
   ============================================================ */
function guardarSesion(data) {
  localStorage.setItem('cf_token',    data.token);
  localStorage.setItem('cf_usuarioId', data.usuarioId);
  localStorage.setItem('cf_email',    data.email);
  localStorage.setItem('cf_nombre',   data.nombreCompleto);
  localStorage.setItem('cf_rol',      data.rol);
}

/* ============================================================
   LOGIN
   ============================================================ */
async function handleLogin(e) {
  e.preventDefault();
  clearError();

  const email     = $('login-email').value.trim();
  const password  = $('login-password').value;
  const btn       = $('login-btn');

  if (!email || !password) {
    showError('Completa todos los campos.');
    return;
  }

  setLoading(btn, true);

  try {
    const res = await fetch(`${API}/autenticacion/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, contrasena: password })
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Credenciales incorrectas.');
    }

    const data = await res.json();
    guardarSesion(data);
    toast('Acceso concedido. Redirigiendo...', 'success');

    setTimeout(() => redirigirPorRol(data.rol), 800);

  } catch (err) {
    showError(err.message);
    toast(err.message, 'error');
  } finally {
    setLoading(btn, false);
  }
}

/* ============================================================
   REGISTRO
   ============================================================ */
async function handleRegistro(e) {
  e.preventDefault();
  clearError();

  const nombre    = $('reg-nombre').value.trim();
  const email     = $('reg-email').value.trim();
  const password  = $('reg-password').value;
  const confirm   = $('reg-confirm').value;
  const rol       = $('reg-rol').value;
  const btn       = $('reg-btn');

  if (!nombre || !email || !password || !confirm || !rol) {
    showError('Completa todos los campos.');
    return;
  }

  if (password !== confirm) {
    showError('Las contraseñas no coinciden.');
    return;
  }

  if (password.length < 6) {
    showError('La contraseña debe tener al menos 6 caracteres.');
    return;
  }

  setLoading(btn, true);

  try {
    const res = await fetch(`${API}/autenticacion/registrar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        nombreCompleto: nombre,
        email,
        contrasena: password,
        rol
      })
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Error al registrar usuario.');
    }

    toast('Usuario registrado. Inicia sesión.', 'success');

    // Cambiar a tab de login
    document.querySelector('[data-tab="section-login"]').click();
    $('login-email').value = email;

  } catch (err) {
    showError(err.message);
    toast(err.message, 'error');
  } finally {
    setLoading(btn, false);
  }
}

/* ============================================================
   VERIFICAR SI YA HAY SESIÓN ACTIVA
   ============================================================ */
function verificarSesionExistente() {
  const token = localStorage.getItem('cf_token');
  const rol   = localStorage.getItem('cf_rol');
  if (token && rol) {
    redirigirPorRol(rol);
  }
}

/* ============================================================
   EFECTO TYPING en el placeholder del email
   ============================================================ */
function initTypingEffect() {
  const input = $('login-email');
  if (!input) return;
  const texts = ['usuario@folio.lp3', 'admin@cyberfolio.io', 'instructor@sec.lp3'];
  let i = 0;
  let charI = 0;
  let deleting = false;

  function type() {
    const current = texts[i % texts.length];
    if (!deleting) {
      input.placeholder = current.slice(0, charI++);
      if (charI > current.length) {
        deleting = true;
        setTimeout(type, 1200);
        return;
      }
    } else {
      input.placeholder = current.slice(0, charI--);
      if (charI < 0) {
        deleting = false;
        i++;
        charI = 0;
      }
    }
    setTimeout(type, deleting ? 40 : 80);
  }
  setTimeout(type, 600);
}

/* ============================================================
   TOGGLE PASSWORD VISIBILITY
   ============================================================ */
function initTogglePassword() {
  document.querySelectorAll('.toggle-pass').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.dataset.target;
      const input = $(targetId);
      if (!input) return;
      const isPass = input.type === 'password';
      input.type = isPass ? 'text' : 'password';
      btn.querySelector('i').className = `ti ${isPass ? 'ti-eye-off' : 'ti-eye'}`;
    });
  });
}

/* ============================================================
   INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  verificarSesionExistente();
  initTabs();
  initTypingEffect();
  initTogglePassword();

  $('login-form-el')?.addEventListener('submit', handleLogin);
  $('reg-form-el')?.addEventListener('submit', handleRegistro);
});
